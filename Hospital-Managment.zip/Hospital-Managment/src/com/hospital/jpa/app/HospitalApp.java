package com.hospital.jpa.app;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import com.hospital.jpa.entity.Bill;
import com.hospital.jpa.entity.Doctor;
import com.hospital.jpa.entity.DoctorAttendance;
import com.hospital.jpa.entity.Medicine;
import com.hospital.jpa.entity.Patient;
import com.hospital.jpa.entity.PatientHistory;
import com.hospital.jpa.entity.PatientMapping;
import com.hospital.jpa.entity.Room;
import com.hospital.jpa.app.HospitalApp;
import com.hospital.jpa.controller.DoctorAttendanceController;
import com.hospital.jpa.controller.DoctorController;
import com.hospital.jpa.controller.PatientHistoryController;
import com.hospital.jpa.controller.PatientMappingController;
import com.hospital.jpa.controller.RoomController;
import com.hospital.jpa.controller.MedicineController;
import com.hospital.jpa.controller.PatientController;

public class HospitalApp
{
	
	
	public Doctor inputDoctorData(Scanner sc) 
	{
		System.out.println("Doctor Name:");
		String dName= sc.next();
		System.out.println("Doctor Gender :");
		String dGender= sc.next();
		System.out.println("Doctor Qualification:");
		String dQualification= sc.next();
		System.out.println("Doctor Address:");
		String dAddress= sc.next();
		System.out.println("Doctor Phone Number:");
		long dPhone= sc.nextLong();
		System.out.println("Doctor Email:");
		String dEmail= sc.next();
		System.out.println("Doctor Specialization:");
		String dSpecialization= sc.next();
		System.out.println("Doctor Password:");
		String dPassword= sc.next();
		Doctor doc = new Doctor();
		doc.setdName(dName);
		doc.setdGender(dGender);
		doc.setdQualification(dQualification);
		doc.setdAddress(dAddress);
		doc.setdPhone(dPhone);
		doc.setdEmail(dEmail);
		doc.setdSpecialization(dSpecialization);
		doc.setdPassword(dPassword);
		doc.setdAvailable("Y");
		doc.setdStatus("N");
		return doc;
	}
	public Patient inputPatientData(Scanner sc)
	{
		System.out.println("Patient name:");
		String pName= sc.next();
		System.out.println("Patient Gender :");
		String pGender= sc.next();
		System.out.println("Patient Age:");
		Long pAge= sc.nextLong();
		System.out.println("Patient Address:");
		String pAddress= sc.next();
		System.out.println("Patient phone number:");
		long pPhone= sc.nextLong();
		System.out.println("Patient Email");
		String pEmail= sc.next();
		System.out.println("Patient Disease:");
		String pDisease= sc.next();
		System.out.println("Patient Password:");
		String pPassword= sc.next();
		Patient pat = new Patient();
		pat.setpName(pName);
		pat.setpGender(pGender);
		pat.setpAge(pAge);
		pat.setpAddress(pAddress);
		pat.setpPhone(pPhone);
		pat.setpEmail(pEmail);
		pat.setpDisease(pDisease);
		pat.setpPassword(pPassword);
		pat.setpStatus("N");
		pat.setpCurrentStatus("N");
		return pat;
	}
	public Room inputRoomData(Scanner sc) 
	{
		System.out.println("Room Type:");
		String rType= sc.next();
		System.out.println("Floor Number of Room:");
		Long rFloorNo= sc.nextLong();
		System.out.println("Cost of Room per Day:");
		float rCostPerDay= sc.nextFloat();
		Room rm= new Room();
		rm.setrType(rType);
		rm.setrfloorNo(rFloorNo);
		rm.setrCostPerDay(rCostPerDay);
		rm.setrAvailability("Y");
		return rm;
	}
	public Medicine inputMedicineData(Scanner sc) 
	{
		System.out.println("Medicine Name:");
		String mName= sc.next();
		System.out.println("Medicine Price:");
		float mPrice= sc.nextFloat();
		System.out.println("Medicine Quantity:");
		long mQuantity=sc.nextLong();
		Medicine md= new Medicine();
		md.setmName(mName);
		md.setmPrice(mPrice);
		md.setmQuantity(mQuantity);
		return md;		
	}
	public PatientHistory inputPatientHistoryData(Scanner sc)
	{   System.out.println("select Patient Id:");
	Long patientId= sc.nextLong();
	System.out.println("Review of Patient:");
	String reviewContent= sc.next();
	System.out.println("Medicine Suggested:");
	String madicineSuggested= sc.next();
	DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
	Date d= Calendar.getInstance().getTime();
	String date= dateformat.format(d); 
	PatientHistory ph = new PatientHistory();
	ph.setPatientId(patientId);
	ph.setReviewContent(reviewContent);
	ph.setMadicineSuggested(madicineSuggested); 
	ph.setDate(date);
	return ph;
	}
	public PatientMapping inputPatientMappingData(Scanner sc)
	{
		System.out.println("Select Patient Id:");
		Long patientId= sc.nextLong();
		System.out.println("Select Doctor Id:");
		Long doctorId= sc.nextLong();
		System.out.println("Select Room Id:");
		Long roomId= sc.nextLong();	
		PatientMapping pm= new PatientMapping();
		pm.setPatientId(patientId);	
		pm.setDoctorId(doctorId);
		pm.setRoomId(roomId);
		DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
		Date d= Calendar.getInstance().getTime();
		String date= dateformat.format(d); 
		pm.setDate(date); 
		return pm;		
	}
	public Bill inputBillData(Scanner sc)
	{   
		System.out.println("Select Patient Id:");
		Long patientId= sc.nextLong();
		float overAllBill=sc.nextFloat();
		Bill b= new Bill();
		b.setPatientId(patientId);
		b.setOverAllBill(overAllBill);
		b.setBillPaid("N");
		return b;
	}
	public static void main(String[] args) 
	{
		DoctorController dController= new DoctorController();
		DoctorAttendanceController daController= new DoctorAttendanceController();
		PatientController pController= new PatientController();
		RoomController rController= new RoomController();
		MedicineController mController= new MedicineController();
		PatientHistoryController phController= new PatientHistoryController();
		PatientMappingController pmController = new PatientMappingController();
		HospitalApp happ= new HospitalApp();
		Scanner sc= new Scanner(System.in);
		String choice = "y";
		do {
			System.out.println("1.Admin");
			System.out.println("2.Doctor");
			System.out.println("3.Patient");
			System.out.println("Select your choice");
			int opt= sc.nextInt();
			if (opt==1) 
			{
				System.out.println("Admin Id:");
				String aid=sc.next();
				System.out.println("Admin Password:");
				String apwd=sc.next();			
				if (aid.equals("Admin") && (apwd.equals("Admin"))) 
				{			
					String choice1 = "y";
					do {
						System.out.println("1.Approval of Doctor");
						System.out.println("2.Approval of Patient");
						System.out.println("3.Room Creation");
						System.out.println("4.Mapping Doctor and Room to Patient");
						System.out.println("5.Patient Bill Generation");
						System.out.println("6.Update Medicine Details");
						System.out.println("Choose one option");
						int opt1=sc.nextInt();
						if(opt1==1)
						{
							System.out.println("Not Approved Doctors:-");
							List<Doctor> doctor=dController.getDoctorDetails();
							int count = 0;
							for(Doctor dc:doctor)
							{
								if(dc.getdStatus().equals("N")) 
								{
									System.out.println("DOCTORID"+"---"+"NAME");
									System.out.println(dc.getdId()+"---"+dc.getdName());
									count++;
								}
							}	
							if (count>0) {

								System.out.println("Doctor Id:");
								Long dId= sc.nextLong();											
								dController.updateDoctorStatus(dId);
								System.out.println("Doctor Status updated");
							}
							else {
								System.out.println("No Doctor to Approve by Admin");
							}
						}
						else if(opt1==2)
						{		
							System.out.println("Not Approved Patients:-");
							List<Patient> patient=pController.getPatientDetails();
							int count=0;
							for(Patient pt:patient)
							{
								if(pt.getpStatus().equals("N")) 
								{
									System.out.println("PatientID"+"---"+"NAME");
									System.out.println(pt.getpId()+"---"+pt.getpName());
									count++;
								}
							}
							if(count>0) {
								System.out.println("Patient Id:");
								Long pId= sc.nextLong();					
								Patient p= new Patient();
								p.setpId(pId);
								pController.updatePatientStatus(pId);
								pController.updatePatientCurrentStatus(p);
								System.out.println("Patient Status and patient Current Status updated");
							}
							else 
							{
								System.out.println("No Patients to Approve by Admin");
							}
						}
						else if(opt1==3)
						{
							Room r =happ.inputRoomData(sc); 
							rController.insertRoom(r);
							System.out.println("New Room Details Rigistered"); 
						}
						else if(opt1==4)
						{
							System.out.println("Available Doctors:-");
							List<Doctor> doctor=dController.getDoctorDetails();
							for(Doctor dc:doctor)
							{
								System.out.println("DOCTORID"+"---"+"NAME"+"---"+"SPECIALIZATION");
								System.out.println(dc.getdId()+"---"+dc.getdName()+"---"+dc.getdSpecialization());
							}
							System.out.println();
							System.out.println("Available Patients:-");
							List<Patient> patient=pController.getPatientDetails();
							for(Patient pt:patient)
							{
								System.out.println("PatientID"+"---"+"NAME"+"---"+"DISEASE");
								System.out.println(pt.getpId()+"---"+pt.getpName()+"---"+pt.getpDisease());
							}
							System.out.println();
							System.out.println("Available Rooms:-");
							List<Room> room=rController.getRoomDetails();
							for(Room rm:room)
							{
								System.out.println("ROOMID"+"---"+"TYPE"+"---"+"COST PER DAY");
								System.out.println(rm.getrId()+"---"+rm.getrType()+"---"+rm.getrCostPerDay());
							}						
							PatientMapping pm =happ.inputPatientMappingData(sc); 
							pmController.insertPatientMapping(pm);
							System.out.println();
							System.out.println("Doctor and Room are Assigned to a Patient"); 
						}
						else if(opt1==5)
						{

						}
						else if(opt1==6)
						{
							Medicine m =happ.inputMedicineData(sc); 
							mController.insertMedicine(m);
							System.out.println("New Medicine Details are Registered"); 
						}

						else{
							System.out.println("Choose correctly");
						}
						System.out.println("Do you  want to continue?   if 'yes' type 'y' if 'no' type 'n'");
						choice1= sc.next();
					}
					while(choice1.equals("y"));
				}	
				else {System.out.println("Wrong Credentials");}
			}
			else if(opt==2) 
			{		
				System.out.println("1.New Doctor Registration");
				System.out.println("2.Doctor Login");
				System.out.println("Choose one Option");
				int c=sc.nextInt();
				if(c==1) 
				{
					Doctor d =happ.inputDoctorData(sc); 
					dController.insertDoctor(d);
					System.out.println("Doctor Rigistered Successfully"); 
				}
				else if(c==2)
				{
					System.out.println("Doctor Id:");
					Long dId=sc.nextLong();
					System.out.println("Doctor password");
					String dPassword= sc.next();
					String originalPassword=dController.getDoctorPassword(dId);
					if(dPassword.equals(originalPassword))
					{
						String choice1 = "y";
						do {
							System.out.println("1.Update Patient History");
							System.out.println("2.Password Change");
							System.out.println("3.Update Attendance");
							System.out.println("Select your choice");
							int cho= sc.nextInt();
							if(cho==1) {
								System.out.println("Available Patients:-");
								List<Patient> patient=pController.getPatientDetails();
								for(Patient pt:patient)
								{
									System.out.println("PATIENTID"+"---"+"NAME");
									System.out.println(pt.getpId()+"---"+pt.getpName());
								}

								PatientHistory ph =happ.inputPatientHistoryData(sc); 
								phController.insertPatientHistory(ph);
								System.out.println();
								System.out.println("Doctor Updated the Patient History"); 
							}

							else if(cho==2)
							{							
								System.out.println("Enter new Password");
								String dPassword1=sc.next();
								System.out.println("Confirm new Password");
								String dPassword11=sc.next(); 
								if(dPassword1.equals(dPassword11))
								{
									dController.updatePassword(dId,dPassword1);
									System.out.println("Password changed successfully");	
								}			                        
								else 
								{
									System.out.println("Inavalid credentials, Please try again");
								}
							}
							else if(cho==3)
							{
								DoctorAttendance da= new DoctorAttendance();
								DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
								Date d= Calendar.getInstance().getTime();
								String date= dateformat.format(d); 
								da.setDoctorId(dId);
								da.setDate(date);
								da.setAttendance("Y");
								daController.insertDoctorAttendance(da);
								System.out.println("Doctor Attendance updated successfully");
							}
							else
							{
								System.out.println("Choose correctly");
							}
							System.out.println("Do you  want to continue?   if 'yes' type 'y' if 'no' type 'n'");
							choice1= sc.next();
						}
						while(choice1.equals("y"));
					}
					else if(originalPassword.equals("Doctor not Approved by admin"))
					{
						System.out.println("Please take admin Approval");
					}
					else {
						System.out.println("Invalid Credentials, please try again");
					}
				}
				else {System.out.println("choose correctly");}
			}
			else if(opt==3) 
			{
				System.out.println("1.New Patient Registration");
				System.out.println("2.Patient Login");
				System.out.println("Choose one Option");
				int ch=sc.nextInt();
				if(ch==1)
				{
					Patient p =happ.inputPatientData(sc); 
					pController.insertPatient(p);
					System.out.println("Patient Registered Successfully"); 
				}			
				else if(ch==2)
				{
					System.out.println("Patient Id:");
					Long pId=sc.nextLong();
					System.out.println("Patient Password");
					String pPassword= sc.next();
					String originalPassword=pController.getPatientPassword(pId);
					if(pPassword.equals(originalPassword)) 
					{
						String choice1 = "y";
						do {
							System.out.println("1.View Patient History");
							System.out.println("2.Password Change");
							System.out.println("3.Bill Payment");
							System.out.println("Choose one Option");
							int ch1=sc.nextInt();
							if(ch1==1)
							{
								List<PatientHistory> PatientHistory=phController.getPatientHistoryDetails();
								for(PatientHistory ph:PatientHistory)
								{
									System.out.println("SNo."+"---"+"PATIENTID"+"---"+"REVIEW CONTENT"+"---"+"MADICINE SUGGESTED");
									System.out.println(ph.getsNo()+"---"+ph.getPatientId()+"---"+ph.getDate()+"---"+ph.getReviewContent()+"---"+ph.getMadicineSuggested());
								}
							}
							else if(ch1==2) 
							{
								System.out.println("Enter new Password");
								String pPassword1=sc.next();
								System.out.println("Confirm new Password");
								String pPassword11=sc.next();                          
								if(pPassword1.equals(pPassword11))
								{
									pController.updatePassword(pId,pPassword1);
									System.out.println("Password changed successfully");	
								}			                        
								else {System.out.println("Inavalid credentials, Please try again");}
							}

							else if(ch1==3)
							{

							}
							else {System.out.println("choose correctly");}
							System.out.println("Do you  want to continue?   if 'yes' type 'y' if 'no' type 'n'");
							choice1= sc.next();
						}
						while(choice1.equals("y"));
					}
					else if(originalPassword.equals("Patient not Approved by admin"))
					{
						System.out.println("Please take admin Approval");
					}
					else {System.out.println("Wrong credentials, please try again");}
				}				
				else
				{
					System.out.println("Inavalid option");
				}
			}
			else
			{
				System.out.println("Invalid option");
			}
			System.out.println("Do you  want to continue?   if 'yes' type 'y' if 'no' type 'n'");
			choice= sc.next();
		}
		while(choice.equals("y"));
		System.out.println("Thank You (:>)");
		System.exit(0);
	}
}