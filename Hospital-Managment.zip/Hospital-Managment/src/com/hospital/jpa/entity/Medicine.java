package com.hospital.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="medicine")
public class Medicine {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long mId;
	private String mName;
	private float mPrice;
	private long mQuantity;
	public Long getmId() {
		return mId;
	}
	public void setmId(Long mId) {
		this.mId = mId;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public float getmPrice() {
		return mPrice;
	}
	public void setmPrice(float mPrice) {
		this.mPrice = mPrice;
	}
	public long getmQuantity() {
		return mQuantity;
	}
	public void setmQuantity(long mQuantity) {
		this.mQuantity = mQuantity;
	}
}
