package com.hospital.jpa.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="doctor")
public class Doctor {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long dId;
	private String dName;
	private String dGender;
	private String dQualification;
	private String dAddress;
	private Long dPhone;
	private String dEmail;
	private String dSpecialization;
	private String dPassword;
	private String dAvailable;
	private String dStatus;
	
	@OneToMany(targetEntity=Patient.class)  
    private List<Patient>patientlist;
	
	public Long getdId() {
		return dId;
	}
	public void setdId(Long dId) {
		this.dId = dId;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public String getdGender() {
		return dGender;
	}
	public void setdGender(String dGender) {
		this.dGender = dGender;
	}
	public String getdQualification() {
		return dQualification;
	}
	public void setdQualification(String dQualification) {
		this.dQualification = dQualification;
	}
	public String getdAddress() {
		return dAddress;
	}
	public void setdAddress(String dAddress) {
		this.dAddress = dAddress;
	}
	public Long getdPhone() {
		return dPhone;
	}
	public void setdPhone(long dPhone) {
		this.dPhone = dPhone;
	}
	public String getdEmail() {
		return dEmail;
	}
	public void setdEmail(String dEmail) {
		this.dEmail = dEmail;
	}
	public String getdSpecialization() {
		return dSpecialization;
	}
	public void setdSpecialization(String dSpecialization) {
		this.dSpecialization = dSpecialization;
	}
	public String getdPassword() {
		return dPassword;
	}
	public void setdPassword(String dPassword) {
		this.dPassword = dPassword;
	}
	public String getdAvailable() {
		return dAvailable;
	}
	public void setdAvailable(String davailable) {
		dAvailable = davailable;
	}
	public String getdStatus() {
		return dStatus;
	}
	public void setdStatus(String dStatus) {
		this.dStatus = dStatus;
	}
}