package com.hospital.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="room")
public class Room {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long rId;
	private String rType;
	private Long rFloorNo;
	private float rCostPerDay;
	private String rAvailability;
	public Long getrId() {
		return rId;
	}
	public void setrId(Long rId) {
		this.rId = rId;
	}
	public String getrType() {
		return rType;
	}
	public void setrType(String rType) {
		this.rType = rType;
	}
	public Long getRfloorNo() {
		return rFloorNo;
	}
	public void setrfloorNo(Long rfloorNo) {
		this.rFloorNo = rfloorNo;
	}
	public float getrCostPerDay() {
		return rCostPerDay;
	}
	public void setrCostPerDay(float rCostPerDay) {
		this.rCostPerDay = rCostPerDay;
	}
	public String getrAvailability() {
		return rAvailability;
	}
	public String setrAvailability(String rAvailability) {
		this.rAvailability = rAvailability;
		return rAvailability;
	}
}