package com.hospital.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bill")
public class Bill {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long billId;
	private Long patientId;
	private float overAllBill;
	private String billPaid;
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public float getOverAllBill() {
		return overAllBill;
	}
	public void setOverAllBill(float overAllBill) {
		this.overAllBill = overAllBill;
	}
	public String getBillPaid() {
		return billPaid;
	}
	public void setBillPaid(String billPaid) {
		this.billPaid = billPaid;
	}
}