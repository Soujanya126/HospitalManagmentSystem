package com.hospital.jpa.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient")
public class Patient {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long pId;
	private String pName;
	private String pGender;
	private Long pAge;
	private String pAddress;
	private Long pPhone;
	private String pEmail;
	private String pDisease;
	private String pStatus;
	private String pPassword;
	private String pCurrentStatus;
	
	public Patient()
	{
		super();
	}
	
	
	public Patient(Long pId, String pName, String pGender, Long pAge, String pAddress, Long pPhone, String pEmail,
			String pDisease, String pStatus, String pPassword, String pCurrentStatus) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pGender = pGender;
		this.pAge = pAge;
		this.pAddress = pAddress;
		this.pPhone = pPhone;
		this.pEmail = pEmail;
		this.pDisease = pDisease;
		this.pStatus = pStatus;
		this.pPassword = pPassword;
		this.pCurrentStatus = pCurrentStatus;
	}
	public String getpCurrentStatus() {
		return pCurrentStatus;
	}
	public void setpCurrentStatus(String pCurrentStatus) {
		this.pCurrentStatus = pCurrentStatus;
	}
	public Long getpId() {
		return pId;
	}
	public void setpId(Long pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpGender() {
		return pGender;
	}
	public void setpGender(String pGender) {
		this.pGender = pGender;
	}
	public long getpAge() {
		return pAge;
	}
	public void setpAge(Long pAge) {
		this.pAge = pAge;
	}
	public String getpAddress() {
		return pAddress;
	}
	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}
	public Long getpPhone() {
		return pPhone;
	}
	public void setpPhone(long pPhone) {
		this.pPhone = pPhone;
	}
	public String getpEmail() {
		return pEmail;
	}
	public void setpEmail(String pEmail) {
		this.pEmail = pEmail;
	}
	public String getpDisease() {
		return pDisease;
	}
	public void setpDisease(String pDisease) {
		this.pDisease = pDisease;
	}
	public String getpStatus() {
		return pStatus;
	}
	public void setpStatus(String pStatus) {
		this.pStatus = pStatus;
	}
	public String getpPassword() {

		return pPassword;
	}
	public void setpPassword(String pPassword) {
		this.pPassword = pPassword;
	}
	
	
	
}