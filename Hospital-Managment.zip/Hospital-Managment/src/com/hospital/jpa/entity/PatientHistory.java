package com.hospital.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patienthistory")
public class PatientHistory {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sNo;
	private long patientId;
	private String reviewContent;
	private String madicineSuggested;
	private String date;
	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public long getsNo() {
		return sNo;
	}
	public void setsNo(long sNo) {
		this.sNo = sNo;
	}
	public String getReviewContent() {
		return reviewContent;
	}
	public void setReviewContent(String reviewContent) {
		this.reviewContent = reviewContent;
	}
	public String getMadicineSuggested() {
		return madicineSuggested;
	}
	public void setMadicineSuggested(String madicineSuggested) {
		this.madicineSuggested = madicineSuggested;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

}