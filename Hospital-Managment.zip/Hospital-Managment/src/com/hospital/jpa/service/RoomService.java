package com.hospital.jpa.service;

import java.util.List;

import com.hospital.jpa.entity.Room;

public interface RoomService {
	public Room registerRoom(Room r);
	public List<Room> getRoomList();
}