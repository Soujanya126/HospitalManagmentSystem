package com.hospital.jpa.service;

import java.util.List;

import com.hospital.jpa.entity.Patient;
import com.hospital.jpa.entity.PatientMapping;

public interface PatientMappingService {
	public PatientMapping registerPatientMapping(PatientMapping mappingId);
}