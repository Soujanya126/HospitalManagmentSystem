
package com.hospital.jpa.service;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.hospital.jpa.entity.Doctor;
import com.hospital.jpa.config.AppConfig;

public class DoctorServiceImpl implements DoctorService {

	EntityManager em = null;
	public DoctorServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public Doctor registerDoctor(Doctor d) {
		em.getTransaction().begin();
		em.persist(d);
		em.getTransaction().commit();
		return d;
	}
	@Override
	public void updateDoctorStatus(Long dId) {
		Doctor doc= em.find(Doctor.class,dId);
		em.getTransaction().begin();
		doc.setdStatus("Y");
		em.persist(doc);
		em.getTransaction().commit();
	}
	@Override
	public String getDoctorPassword(Long dId) {
		Doctor doc=em.find(Doctor.class, dId);
		if(doc.getdStatus().equals("Y"))
			return doc.getdPassword();
		else
			return "Doctor not Approved by admin";
	}
	@Override
	public List<Doctor> getDoctorList() {
		Query q=em.createQuery("select d from Doctor d");
		List<Doctor> l=q.getResultList();
		Iterator<Doctor> i=l.iterator();
		List<Doctor> al= new ArrayList<Doctor>();
		while(i.hasNext())
		{
			Doctor d=i.next();
			al.add(d);
		}
		return al;
	}
	@Override
	public void updatePassword(Long dId, String newPassword) {
		Doctor doc=em.find(Doctor.class,dId);
		em.getTransaction().begin();
		doc.setdPassword(newPassword);
		em.persist(doc);
		em.getTransaction().commit();
	}


}