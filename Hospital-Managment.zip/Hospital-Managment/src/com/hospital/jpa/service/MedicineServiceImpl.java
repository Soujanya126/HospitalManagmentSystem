package com.hospital.jpa.service;

import javax.persistence.EntityManager;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.Medicine;

public class MedicineServiceImpl implements MedicineService {
	EntityManager em = null;
	public MedicineServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public Medicine registerMedicine(Medicine m) {
		em.getTransaction().begin();
		em.persist(m);
		em.getTransaction().commit();
		return m;
	}
}