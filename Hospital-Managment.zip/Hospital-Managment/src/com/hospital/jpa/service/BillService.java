package com.hospital.jpa.service;

import com.hospital.jpa.entity.Bill;

public interface BillService {
	public Bill registerBill(Bill b);
}

