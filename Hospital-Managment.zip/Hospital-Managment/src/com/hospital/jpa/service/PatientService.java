package com.hospital.jpa.service;

import java.util.List;

import com.hospital.jpa.entity.Patient;

public interface PatientService   {
	public Patient registerPatient(Patient p);
	public void updatePatientStatus(Long pId);
	public String getPatientPassword(Long pId);
	public void updatePatientCurrentStatus(Patient p);
	public List<Patient> getPatientList();
	public void updatePassword(Long pId,String newPassword);
}