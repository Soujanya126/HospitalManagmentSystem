package com.hospital.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.Room;

public class RoomServiceImpl implements RoomService {
	EntityManager em = null;
	public RoomServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public Room registerRoom(Room r) {
		em.getTransaction().begin();
		em.persist(r);
		em.getTransaction().commit();
		return r;
	}
	@Override
	public List<Room> getRoomList() {
		Query q=em.createQuery("select r from Room r");
		List<Room> l=q.getResultList();
		Iterator<Room> i=l.iterator();
		List<Room> al= new ArrayList<Room>();
		while(i.hasNext())
		{
			Room r=i.next();
			al.add(r);
		}
		return al;
	}
}