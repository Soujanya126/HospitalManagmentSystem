
package com.hospital.jpa.service;

import javax.persistence.EntityManager;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.Bill;

public class BillServiceImpl implements BillService {
	EntityManager em = null;
	public BillServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public Bill registerBill(Bill b) {
		em.getTransaction().begin();
		em.persist(b);
		em.getTransaction().commit();
		return b;
	}
}
