package com.hospital.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.Patient;

public class PatientServiceImpl implements PatientService  {
	EntityManager em = null;
	public PatientServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public Patient registerPatient(Patient p) {
		em.getTransaction().begin();
		em.persist(p);
		em.getTransaction().commit();
		return p;
	}
	@Override
	public void updatePatientStatus(Long pId) {

		Patient pat= em.find(Patient.class,pId);
		em.getTransaction().begin();
		pat.setpStatus("Y");
		em.persist(pat);
		em.getTransaction().commit();		
	}
	@Override
	public String getPatientPassword(Long pId) {
		Patient pat= em.find(Patient.class,pId);
		if(pat.getpStatus().equals("Y"))
			return pat.getpPassword();
		else
			return "Patient not Approved by admin";
	}
	@Override
	public void updatePatientCurrentStatus(Patient p) {
		Patient pat= em.find(Patient.class,p.getpId());
		em.getTransaction().begin();
		pat.setpCurrentStatus("In Progress");
		em.persist(pat);
		em.getTransaction().commit();	
	}
	@Override
	public List<Patient> getPatientList() {
		Query q=em.createQuery("select p from Patient p");
		List<Patient> l=q.getResultList();
		Iterator<Patient> i=l.iterator();
		List<Patient> al= new ArrayList<Patient>();
		while(i.hasNext())
		{
			Patient p=i.next();
			al.add(p);
		}
		return al;
	}
	@Override
	public void updatePassword(Long pId, String newPassword) {
		Patient pat= em.find(Patient.class, pId);
		em.getTransaction().begin();
		pat.setpPassword(newPassword);
		em.persist(pat);
		em.getTransaction().commit();	
	}


}