package com.hospital.jpa.service;

import javax.persistence.EntityManager;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.PatientMapping;
import com.hospital.jpa.entity.Room;

public class PatientMappingServiceImpl implements  PatientMappingService{
	EntityManager em = null;
	public PatientMappingServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public PatientMapping registerPatientMapping(PatientMapping mappingId) {
		em.getTransaction().begin();
		em.persist(mappingId);
		Room r= em.find(Room.class,mappingId.getRoomId());
		r.setrAvailability("N");
		em.persist(r);
		em.getTransaction().commit();
		return mappingId;
	}
}