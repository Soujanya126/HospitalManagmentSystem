package com.hospital.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.PatientHistory;

public class PatientHistoryServiceImpl implements PatientHistoryService {
	EntityManager em = null;
	public PatientHistoryServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public PatientHistory registerPatientHistory(PatientHistory ph) {
		em.getTransaction().begin();
		em.persist(ph);
		em.getTransaction().commit();
		return ph;
	}
	@Override
	public List<PatientHistory> getPatientHistoryList() {
		Query q=em.createQuery("select ph from PatientHistory ph");
		List<PatientHistory>l=q. getResultList();
		Iterator<PatientHistory> i=l.iterator();
		List<PatientHistory> al= new ArrayList<PatientHistory>();
		while(i.hasNext())
		{
			PatientHistory ph=i.next();
			al.add(ph);
		}
		return al;
	}
}