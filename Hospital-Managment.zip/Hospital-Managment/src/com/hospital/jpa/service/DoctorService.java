package com.hospital.jpa.service;

import java.util.List;
import com.hospital.jpa.entity.Doctor;

public interface DoctorService {
	public Doctor registerDoctor(Doctor d);
	public void updateDoctorStatus(Long dId);
	public String getDoctorPassword(Long dId);
	public List<Doctor> getDoctorList();
	public void updatePassword(Long dId,String newPassword);
}
