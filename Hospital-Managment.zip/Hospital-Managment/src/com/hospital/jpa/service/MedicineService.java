package com.hospital.jpa.service;

import com.hospital.jpa.entity.Medicine;

public interface MedicineService {
	public Medicine registerMedicine(Medicine m);
}

