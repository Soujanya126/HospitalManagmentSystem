package com.hospital.jpa.service;

import com.hospital.jpa.entity.DoctorAttendance;

public interface DoctorAttendanceService {
	public DoctorAttendance registerDoctorAttendance(DoctorAttendance da);
}
