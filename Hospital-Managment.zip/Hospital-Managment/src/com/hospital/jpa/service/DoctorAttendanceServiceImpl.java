package com.hospital.jpa.service;
import javax.persistence.EntityManager;

import com.hospital.jpa.config.AppConfig;
import com.hospital.jpa.entity.DoctorAttendance;
public class DoctorAttendanceServiceImpl implements DoctorAttendanceService {
	EntityManager em = null;
	public DoctorAttendanceServiceImpl() {
		em=AppConfig.getObject().getEntityManager();
	}
	@Override
	public DoctorAttendance registerDoctorAttendance(DoctorAttendance da) {
		em.getTransaction().begin();
		em.persist(da);
		em.getTransaction().commit();
		return da;
	}
}
