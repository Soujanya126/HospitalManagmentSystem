package com.hospital.jpa.service;

import java.util.List;

import com.hospital.jpa.entity.PatientHistory;

public interface PatientHistoryService {
	public PatientHistory registerPatientHistory(PatientHistory ph);
	public List<PatientHistory> getPatientHistoryList();
}