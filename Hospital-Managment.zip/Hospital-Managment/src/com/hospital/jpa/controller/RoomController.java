package com.hospital.jpa.controller;

import java.util.List;

import com.hospital.jpa.entity.Room;
import com.hospital.jpa.service.RoomService;
import com.hospital.jpa.service.RoomServiceImpl;

public class RoomController {
	RoomService rmService = null;
	public RoomController() {
		rmService= new RoomServiceImpl();
	}
	public void insertRoom(Room r) {
		rmService.registerRoom(r);   
	}
	public List<Room> getRoomDetails(){
		List<Room> rm= rmService.getRoomList();
		return rm;
	}
}