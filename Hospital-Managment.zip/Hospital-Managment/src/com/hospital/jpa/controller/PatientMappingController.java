package com.hospital.jpa.controller;

import com.hospital.jpa.entity.PatientMapping;
import com.hospital.jpa.service.PatientMappingService;
import com.hospital.jpa.service.PatientMappingServiceImpl;

public class PatientMappingController {
	PatientMappingService pamService = null;
	public PatientMappingController() {
		pamService= new PatientMappingServiceImpl();
	}
	public PatientMapping insertPatientMapping(PatientMapping mappingId) {
		return pamService.registerPatientMapping(mappingId);   
	}
}