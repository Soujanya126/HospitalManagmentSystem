package com.hospital.jpa.controller;

import com.hospital.jpa.entity.Medicine;
import com.hospital.jpa.service.MedicineService;
import com.hospital.jpa.service.MedicineServiceImpl;

public class MedicineController {
	MedicineService medService = null;
	public MedicineController() {
		medService= new MedicineServiceImpl();
	}
	public void insertMedicine(Medicine m) {
		medService.registerMedicine(m);   
	}
}
