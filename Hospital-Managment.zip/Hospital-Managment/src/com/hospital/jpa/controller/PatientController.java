package com.hospital.jpa.controller;

import java.util.List;
import com.hospital.jpa.entity.Patient;
import com.hospital.jpa.service.PatientService;
import com.hospital.jpa.service.PatientServiceImpl;

public class PatientController {
	PatientService patService = null;
	public PatientController() {
		patService= new PatientServiceImpl();
	}
	public Patient insertPatient(Patient p) {
		return patService.registerPatient(p);   
	}
	public void updatePatientStatus(Long pId) {
		patService.updatePatientStatus(pId);
	}
	public void updatePatientCurrentStatus(Patient p) {
		patService.updatePatientCurrentStatus(p);
	}
	public String getPatientPassword(Long pId) {
		return patService.getPatientPassword(pId);
	}

	public List<Patient> getPatientDetails(){
		List<Patient> pt= patService.getPatientList();
		return pt;
	}
	public void updatePassword(Long pId,String newPassword) {
		patService.updatePassword(pId, newPassword);
	}
}
