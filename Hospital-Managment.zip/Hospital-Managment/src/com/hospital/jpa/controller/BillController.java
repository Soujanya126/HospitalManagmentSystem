package com.hospital.jpa.controller;

import com.hospital.jpa.entity.Bill;
import com.hospital.jpa.service.BillService;
import com.hospital.jpa.service.BillServiceImpl;

public class BillController {
	BillService billService = null;
	public BillController() {
		billService= new BillServiceImpl();
	}
	public void insertDoctor(Bill b) {
		billService.registerBill(b);   
	}
}
