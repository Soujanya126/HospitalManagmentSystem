package com.hospital.jpa.controller;

import java.util.List;

import com.hospital.jpa.entity.Doctor;
import com.hospital.jpa.entity.PatientHistory;
import com.hospital.jpa.service.PatientHistoryService;
import com.hospital.jpa.service.PatientHistoryServiceImpl;

public class PatientHistoryController {
	PatientHistoryService phService = null;
	public PatientHistoryController() {
		phService= new PatientHistoryServiceImpl();
	}
	public void insertPatientHistory(PatientHistory ph) {
		phService.registerPatientHistory(ph);   
	}
	public List<PatientHistory> getPatientHistoryDetails(){
		List<PatientHistory> ph= phService.getPatientHistoryList();
		return ph;
	}
}
