package com.hospital.jpa.controller;

import java.util.List;
import com.hospital.jpa.entity.Doctor;
import com.hospital.jpa.service.DoctorService;
import com.hospital.jpa.service.DoctorServiceImpl;

public class DoctorController {
	DoctorService docService = null;
	public DoctorController() {
		docService= new DoctorServiceImpl();
	}
	public void insertDoctor(Doctor d) {
		docService.registerDoctor(d);   
	}
	public void updateDoctorStatus(Long dId) {
		docService.updateDoctorStatus(dId);
	}
	public String getDoctorPassword(Long dId) {
		return docService.getDoctorPassword(dId);	
	}
	public List<Doctor> getDoctorDetails(){
		List<Doctor> dc= docService.getDoctorList();
		return dc;
	}
	public void updatePassword(Long dId,String newPassword) {
		docService.updatePassword(dId, newPassword);
	}
}