package com.hospital.jpa.controller;

import com.hospital.jpa.entity.DoctorAttendance;
import com.hospital.jpa.service.DoctorAttendanceService;
import com.hospital.jpa.service.DoctorAttendanceServiceImpl;

public class DoctorAttendanceController {
	DoctorAttendanceService daService = null;
	public DoctorAttendanceController() {
		daService= new DoctorAttendanceServiceImpl();
	}
	public void insertDoctorAttendance(DoctorAttendance da) {
		daService.registerDoctorAttendance(da);   
	}
}